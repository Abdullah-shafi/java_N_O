import javax.swing.*;
import java.awt.event.*;
import java.awt.Color;

public class SimpleGUI extends JFrame implements ActionListener
{
	private JLabel label;
	private JTextField textfield;
	private JButton button;
	private ImageIcon on;
	
	public SimpleGUI()
	{
		//title
		super("Java N section");
		//label
		label=new JLabel("Enter Your Name");
		label.setBounds(50,50,200,30);
		
		textfield= new JTextField();
		textfield.setBounds(50,90,200,30);
		on=new ImageIcon("image/tg1.PNG");
		button=new JButton(on);
		button.setBounds(100,150,100,30);
		button.addActionListener(this);
		
		
		add(label);
		add(textfield);
		add(button);
		
		//layout,size
		setLayout(null);
		setSize(300,250);  //(width,height)
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==button)
		{
			setVisible(false);
			new home();
		}
	}
	
	public static void main(String[] args)
	{
		new SimpleGUI();
	}
}